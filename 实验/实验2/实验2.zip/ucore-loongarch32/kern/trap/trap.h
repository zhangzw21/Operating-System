#ifndef __KERN_TRAP_TRAP_H__
#define __KERN_TRAP_TRAP_H__

#include <defs.h>
#include <loongarch_trapframe.h>

void set_exception_handler();

#endif